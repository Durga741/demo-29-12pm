
    document.addEventListener('DOMContentLoaded', function() {
    const languageSelect = document.getElementById('language-select');

    languageSelect.addEventListener('change', (event) => {
        const selectedLanguage = event.target.value;

        // Translate navbar items
        document.querySelectorAll('.navbar a').forEach(navItem => {
            navItem.textContent = navItem.getAttribute(`data-${selectedLanguage}`);
        });

        // Translate other elements (including the hero section)
        document.querySelectorAll('[data-english]').forEach(element => {
            element.textContent = element.getAttribute(`data-${selectedLanguage}`);
        });
    });

    // Smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('.navbar a');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const target = document.querySelector(e.target.getAttribute('href'));
            window.scrollTo({
                top: target.offsetTop,
                behavior: 'smooth'
            });
        });
    });
});

    